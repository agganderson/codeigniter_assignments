<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "Users";
// $route['welcome'] = '/users/welcome';


/* End of file routes.php */
/* Location: ./application/config/routes.php */
?>