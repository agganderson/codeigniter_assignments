<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Original Pokemon</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script>
		$(document).ready(function(){
			var poke = '';
			for(var p = 1; p <= 151; p++){
				poke += '<img src="http://pokeapi.co/media/img/'+p+'.png">';
			}
			$('#pokemon').html(poke);
		})
	</script>
</head>
<body>
	<div id='pokemon'><img src='http://pokeapi.co/media/img/1.png'></div>
</body>
</html>

